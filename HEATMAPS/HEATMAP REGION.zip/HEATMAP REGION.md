# Correlation Heatmap - geographical region

#### Importing the library


```python
import pandas as pd
import numpy as np 
import seaborn as sns
import matplotlib.pyplot as plt
```

#### Importing the data


```python
df = pd.read_excel (r'E:\RESEARCH PROJECT2\AFRICA RESEARCH TREND TO COVID\WOS\DATA 14032021\to analyse\DATA\HEATMAP REGION.xlsx')
print (df)
```

          North America  Latin America & the Caribbean   South Asia   \
    0                 0                               0            0   
    1                 0                               0            0   
    2                 0                               0            0   
    3                 0                               0            0   
    4                 0                               0            0   
    ...             ...                             ...          ...   
    5358              0                               0            0   
    5359              0                               0            0   
    5360              0                               0            0   
    5361              0                               0            0   
    5362              0                               0            0   
    
          East Asia & Pacific   Europe & Central Asia   \
    0                        0                       0   
    1                        0                       0   
    2                        0                       0   
    3                        0                       0   
    4                        0                       0   
    ...                    ...                     ...   
    5358                     0                       0   
    5359                     0                       0   
    5360                     0                       0   
    5361                     0                       0   
    5362                     0                       0   
    
          Middle East & North Africa   Middle East  North Africa  \
    0                               0            0             0   
    1                               0            0             0   
    2                               0            0             0   
    3                               0            0             0   
    4                               0            0             0   
    ...                           ...          ...           ...   
    5358                            0            0             0   
    5359                            0            0             0   
    5360                            0            0             0   
    5361                            0            0             0   
    5362                            0            0             0   
    
          Sub-Saharan Africa   Central Africa  Eastern Africa  Southern Africa  \
    0                       2               0               0                1   
    1                       2               0               1                0   
    2                       2               0               0                2   
    3                       2               0               0                0   
    4                       2               0               1                0   
    ...                   ...             ...             ...              ...   
    5358                    2               0               0                1   
    5359                    1               0               1                0   
    5360                    1               0               1                0   
    5361                    1               0               1                0   
    5362                    1               0               1                0   
    
          Western  Africa  
    0                   1  
    1                   1  
    2                   0  
    3                   2  
    4                   1  
    ...               ...  
    5358                1  
    5359                0  
    5360                0  
    5361                0  
    5362                0  
    
    [5363 rows x 13 columns]
    


```python
df.corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>North America</th>
      <th>Latin America &amp; the Caribbean</th>
      <th>South Asia</th>
      <th>East Asia &amp; Pacific</th>
      <th>Europe &amp; Central Asia</th>
      <th>Middle East &amp; North Africa</th>
      <th>Middle East</th>
      <th>North Africa</th>
      <th>Sub-Saharan Africa</th>
      <th>Central Africa</th>
      <th>Eastern Africa</th>
      <th>Southern Africa</th>
      <th>Western  Africa</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>North America</th>
      <td>1.000000</td>
      <td>0.387594</td>
      <td>0.192392</td>
      <td>0.325181</td>
      <td>0.423320</td>
      <td>0.031408</td>
      <td>0.104294</td>
      <td>-0.060449</td>
      <td>0.163070</td>
      <td>0.032931</td>
      <td>0.084600</td>
      <td>0.131599</td>
      <td>0.049398</td>
    </tr>
    <tr>
      <th>Latin America &amp; the Caribbean</th>
      <td>0.387594</td>
      <td>1.000000</td>
      <td>0.345061</td>
      <td>0.445547</td>
      <td>0.531798</td>
      <td>0.134346</td>
      <td>0.181375</td>
      <td>0.033695</td>
      <td>0.117547</td>
      <td>0.019134</td>
      <td>0.044423</td>
      <td>0.104880</td>
      <td>0.043048</td>
    </tr>
    <tr>
      <th>South Asia</th>
      <td>0.192392</td>
      <td>0.345061</td>
      <td>1.000000</td>
      <td>0.415768</td>
      <td>0.312284</td>
      <td>0.181229</td>
      <td>0.223626</td>
      <td>0.068687</td>
      <td>0.087137</td>
      <td>0.007483</td>
      <td>0.077431</td>
      <td>0.026295</td>
      <td>0.046578</td>
    </tr>
    <tr>
      <th>East Asia &amp; Pacific</th>
      <td>0.325181</td>
      <td>0.445547</td>
      <td>0.415768</td>
      <td>1.000000</td>
      <td>0.517354</td>
      <td>0.145148</td>
      <td>0.208633</td>
      <td>0.022413</td>
      <td>0.120843</td>
      <td>0.006014</td>
      <td>0.031603</td>
      <td>0.105640</td>
      <td>0.066366</td>
    </tr>
    <tr>
      <th>Europe &amp; Central Asia</th>
      <td>0.423320</td>
      <td>0.531798</td>
      <td>0.312284</td>
      <td>0.517354</td>
      <td>1.000000</td>
      <td>0.151253</td>
      <td>0.222734</td>
      <td>0.017476</td>
      <td>0.145351</td>
      <td>0.061500</td>
      <td>0.037757</td>
      <td>0.141637</td>
      <td>0.038772</td>
    </tr>
    <tr>
      <th>Middle East &amp; North Africa</th>
      <td>0.031408</td>
      <td>0.134346</td>
      <td>0.181229</td>
      <td>0.145148</td>
      <td>0.151253</td>
      <td>1.000000</td>
      <td>0.845529</td>
      <td>0.807807</td>
      <td>-0.364211</td>
      <td>-0.102860</td>
      <td>-0.138429</td>
      <td>-0.268011</td>
      <td>-0.170730</td>
    </tr>
    <tr>
      <th>Middle East</th>
      <td>0.104294</td>
      <td>0.181375</td>
      <td>0.223626</td>
      <td>0.208633</td>
      <td>0.222734</td>
      <td>0.845529</td>
      <td>1.000000</td>
      <td>0.368302</td>
      <td>-0.095960</td>
      <td>-0.045930</td>
      <td>-0.018952</td>
      <td>-0.080313</td>
      <td>-0.042357</td>
    </tr>
    <tr>
      <th>North Africa</th>
      <td>-0.060449</td>
      <td>0.033695</td>
      <td>0.068687</td>
      <td>0.022413</td>
      <td>0.017476</td>
      <td>0.807807</td>
      <td>0.368302</td>
      <td>1.000000</td>
      <td>-0.528246</td>
      <td>-0.128399</td>
      <td>-0.220117</td>
      <td>-0.378011</td>
      <td>-0.250523</td>
    </tr>
    <tr>
      <th>Sub-Saharan Africa</th>
      <td>0.163070</td>
      <td>0.117547</td>
      <td>0.087137</td>
      <td>0.120843</td>
      <td>0.145351</td>
      <td>-0.364211</td>
      <td>-0.095960</td>
      <td>-0.528246</td>
      <td>1.000000</td>
      <td>0.350136</td>
      <td>0.533915</td>
      <td>0.502700</td>
      <td>0.533043</td>
    </tr>
    <tr>
      <th>Central Africa</th>
      <td>0.032931</td>
      <td>0.019134</td>
      <td>0.007483</td>
      <td>0.006014</td>
      <td>0.061500</td>
      <td>-0.102860</td>
      <td>-0.045930</td>
      <td>-0.128399</td>
      <td>0.350136</td>
      <td>1.000000</td>
      <td>0.047604</td>
      <td>-0.016548</td>
      <td>0.094754</td>
    </tr>
    <tr>
      <th>Eastern Africa</th>
      <td>0.084600</td>
      <td>0.044423</td>
      <td>0.077431</td>
      <td>0.031603</td>
      <td>0.037757</td>
      <td>-0.138429</td>
      <td>-0.018952</td>
      <td>-0.220117</td>
      <td>0.533915</td>
      <td>0.047604</td>
      <td>1.000000</td>
      <td>-0.042978</td>
      <td>0.000762</td>
    </tr>
    <tr>
      <th>Southern Africa</th>
      <td>0.131599</td>
      <td>0.104880</td>
      <td>0.026295</td>
      <td>0.105640</td>
      <td>0.141637</td>
      <td>-0.268011</td>
      <td>-0.080313</td>
      <td>-0.378011</td>
      <td>0.502700</td>
      <td>-0.016548</td>
      <td>-0.042978</td>
      <td>1.000000</td>
      <td>-0.121161</td>
    </tr>
    <tr>
      <th>Western  Africa</th>
      <td>0.049398</td>
      <td>0.043048</td>
      <td>0.046578</td>
      <td>0.066366</td>
      <td>0.038772</td>
      <td>-0.170730</td>
      <td>-0.042357</td>
      <td>-0.250523</td>
      <td>0.533043</td>
      <td>0.094754</td>
      <td>0.000762</td>
      <td>-0.121161</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
## Understanding the data component
```


```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 5363 entries, 0 to 5362
    Data columns (total 13 columns):
     #   Column                          Non-Null Count  Dtype
    ---  ------                          --------------  -----
     0   North America                   5363 non-null   int64
     1   Latin America & the Caribbean   5363 non-null   int64
     2   South Asia                      5363 non-null   int64
     3   East Asia & Pacific             5363 non-null   int64
     4   Europe & Central Asia           5363 non-null   int64
     5   Middle East & North Africa      5363 non-null   int64
     6   Middle East                     5363 non-null   int64
     7   North Africa                    5363 non-null   int64
     8   Sub-Saharan Africa              5363 non-null   int64
     9   Central Africa                  5363 non-null   int64
     10  Eastern Africa                  5363 non-null   int64
     11  Southern Africa                 5363 non-null   int64
     12  Western  Africa                 5363 non-null   int64
    dtypes: int64(13)
    memory usage: 544.8 KB
    


```python
# Increase the size of the heatmap.
plt.figure(figsize=(36, 18))
# Store heatmap object in a variable to easily access it when you want to include more features (such as title).
# Set the range of values to be displayed on the colormap from -1 to 1, and set the annotation to True to display the correlation values on the heatmap.
heatmap = sns.heatmap(df.corr(), vmin=-1, vmax=1, annot=False, cmap='BrBG')
# Give a title to the heatmap. Pad defines the distance of the title from the top of the heatmap.
heatmap.set_title('Correlation Heatmap - geographical region', fontdict={'fontsize':18}, pad=12);# save heatmap as .png file
# dpi - sets the resolution of the saved image in dots/inches
# bbox_inches - when set to 'tight' - does not allow the labels to be cropped
plt.savefig('heatmap.png', dpi=300, bbox_inches='tight')
```


    
![png](output_8_0.png)
    


#### Triangle Correlation Heatmap


```python
np.triu(np.ones_like(df.corr()))
```




    array([[1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.],
           [0., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.],
           [0., 0., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.],
           [0., 0., 0., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.],
           [0., 0., 0., 0., 1., 1., 1., 1., 1., 1., 1., 1., 1.],
           [0., 0., 0., 0., 0., 1., 1., 1., 1., 1., 1., 1., 1.],
           [0., 0., 0., 0., 0., 0., 1., 1., 1., 1., 1., 1., 1.],
           [0., 0., 0., 0., 0., 0., 0., 1., 1., 1., 1., 1., 1.],
           [0., 0., 0., 0., 0., 0., 0., 0., 1., 1., 1., 1., 1.],
           [0., 0., 0., 0., 0., 0., 0., 0., 0., 1., 1., 1., 1.],
           [0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 1., 1., 1.],
           [0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 1., 1.],
           [0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 1.]])




```python
plt.figure(figsize=(36, 18))
# define the mask to set the values in the upper triangle to True
mask = np.triu(np.ones_like(df.corr(), dtype=np.bool))
heatmap = sns.heatmap(df.corr(), mask=mask, vmin=-1, vmax=1, annot=False, cmap='BrBG')
heatmap.set_title('Triangle Correlation Heatmap - geographical region', fontdict={'fontsize':18}, pad=16);
plt.savefig('Correlation Heatmap - geographical region.png', dpi=300, bbox_inches='tight')
```


    
![png](output_11_0.png)
    



```python

```
